import nodemailer from "nodemailer";

export const handler = async (event) => {
  try {
    const body = JSON.parse(event.body);

    const { name, email, message } = body;

    // Basic Validation
    if (!name || !email || !message) {
      return {
        statuscode: 400,
        body: JSON.stringify({ error: "Kaikki kentät ovat pakollisia" }),
      };
    }

    // Email format check
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailRegex.test(email)) {
      return {
        statuscode: 400,
        body: JSON.stringify({ error: "Sähköposti ei ole validi" }),
      };
    }

    // Transporter

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS },
    });

    const mailOptions = {
      from: email,
      to: process.env.EMAIL_USER,
      subject: `Uusi yhteydenotto: ${name}`,
      text: `Nimi: ${name}\nSähköposti: ${email}\nViesti:\n${message}`,
    };

    // send mail
    await transporter.sendMail(mailOptions);

    return {
      statuscode: 200,
      body: JSON.stringify({ success: true, message: "Mail sent!" }),
    };
  } catch (err) {
    console.error("Lambda error", err);
    return {
      statuscode: 500,
      body: JSON.stringify({ error: "Server error" }),
    };
  }
};
